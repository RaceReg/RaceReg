/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BibEntry;

import Racer.RaceTime;
import Racer.Racer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Jackson Porter
 */
public class BibEntryProgram {
    BibEntryWindow window;
    private List<RaceTime> times;
    final String TABS = "Last Name,First Name,Bib Number,Gender,Age,Race,";
    String[] importReqs;
    private List<Racer> racers;
    private List<String> bibNums;
    String name;
    String date;

    public BibEntryProgram()
    {
        times = new ArrayList<RaceTime>();
        racers = new ArrayList<Racer>();
        
        
         name = "DEFAULT RACE";
        //http://stackoverflow.com/questions/2942857/how-to-convert-current-date-into-string-in-java
        date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        
        
        importReqs = new String[5];
        importReqs[0] = "DO NOT DELETE THESE FIRST FIVE LINES.,,,,,";
        importReqs[1] = "Type in Racer Information under the columns below.,,,,,";
        importReqs[2] = "The only required field is the Bib Number field.,,,,,";
        importReqs[3] = ",,,,,";
        importReqs[4] = "Last Name,First Name,Bib Number,Gender,Age,Race,,,,,";
        
        importTimes();
        importRegistration();
        
        window = new BibEntryWindow(this);
        window.setVisible(true);
        
    }
    
    public BibEntryProgram(List<RaceTime> t)
    { 
        times = new ArrayList<RaceTime>();
        racers = new ArrayList<Racer>();
        
        name = "DEFAULT RACE";
        //http://stackoverflow.com/questions/2942857/how-to-convert-current-date-into-string-in-java
        date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        
        importTimes(t);
        
        importReqs = new String[5];
        importReqs[0] = "DO NOT DELETE THESE FIRST FIVE LINES.,,,,,";
        importReqs[1] = "Type in Racer Information under the columns below.,,,,,";
        importReqs[2] = "The only required field is the Bib Number field.,,,,,";
        importReqs[3] = ",,,,,";
        importReqs[4] = "Last Name,First Name,Bib Number,Gender,Age,Race,,,,,";
        
        String temp = JOptionPane.showInputDialog(null, "Would you like to import a registration file? Type 1 here to import registration. Any other entry will not import registration.", "Import Registration?", JOptionPane.QUESTION_MESSAGE);
        
        if(temp.equals("1"))
            {
                importRegistration();
            }
        else
        {
            JOptionPane.showMessageDialog(null, "Not importing. Manual Input Active.", "Import Registration?", JOptionPane.INFORMATION_MESSAGE);
        }
        
        window = new BibEntryWindow(this);
        window.setVisible(true);
        
        
    }
    
    void importTimes(List<RaceTime> t)
    {
        times = t;
    }
    
    void importTimes()
    {
        JOptionPane.showMessageDialog(window, "Please select the Times CSV file.", "Import Times", JOptionPane.INFORMATION_MESSAGE);

            JFileChooser chooser = new JFileChooser();
            File importFile = null;
            //Importing acutally begins here. 
            try{
                
                 boolean retry = true;
            do{
            if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                importFile = chooser.getSelectedFile();
                retry = false;
            }
            else
                JOptionPane.showMessageDialog(null, "You selected no file. You must select a file.", "Error", JOptionPane.ERROR_MESSAGE);
            }while(retry);
        
                FileReader filein = new FileReader(importFile);
                BufferedReader reader = new BufferedReader(filein);
 
                String lines = "";
                    try{
//                        for(int i = 0; i < 5; i++)
//                        {
                        String line1 = reader.readLine();
                        System.out.println("Line 1 of File: " + line1);
                            if(line1.equals("Time"))
                            {
                                System.out.println("Line" + " is correct.");
                            }
                            else
                            {
                                throw new IOException();
                            }
//                        }
                    
                    do{
                        lines = reader.readLine();
                        System.out.println("Current Line: " + lines);
                        if(lines!= null){
                            times.add(new RaceTime(lines));
                        }
                    }while(lines != null);
                    reader.close();
                    JOptionPane.showMessageDialog(null, "Times Import has completed!\n" + times.get(0).getDoubleStringTime(), "Import", JOptionPane.PLAIN_MESSAGE);
                }catch(IOException e){
                   JOptionPane.showMessageDialog(null, "This file can't be imported."
                           + "\nPlease verify the file matches the Racer Template.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            catch(FileNotFoundException e){
                System.out.println("There was an extreme error.");
            }
    }
    
    public void importRegistration()
    {
       JOptionPane.showMessageDialog(window, "Please select the Registration CSV file.", "Import Times", JOptionPane.INFORMATION_MESSAGE);

           JFileChooser chooser = new JFileChooser();
            File importFile = null;
            //Importing acutally begins here. 
            try{
                
                 boolean retry = true;
            do{
            if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                importFile = chooser.getSelectedFile();
                retry = false;
            }
            else
                JOptionPane.showMessageDialog(null, "You selected no file. You must select a file.", "Error", JOptionPane.ERROR_MESSAGE);
            }while(retry);
        
                FileReader filein = new FileReader(importFile);
                BufferedReader reader = new BufferedReader(filein);
 
                String lines = "";
                    try{
                        for(int i = 0; i < 5; i++)
                        {
                            String temp = reader.readLine();
                            System.out.println(temp);
                            System.out.println(importReqs[i]);
                            if(temp.equals(importReqs[i]))
                            {
                                
                                System.out.println("Line " + i + " is correct.");
                            }
                            else
                            {
                                throw new IOException();
                            }
                        }
                    
                    do{
                        lines = reader.readLine();
                        System.out.println("Current Line: " + lines);
                        if(lines!= null){
                            String [] qualities = lines.split(",");
                            for(int i = 0; i < qualities.length; i++)
                            {
                                System.out.println(i + ": " + qualities[i]);
                            }
                            //String fName, String lName, String age, String race, String bibNum, String gender
                            //first name, last name, bib number, age, gender, race
                            addRacer(qualities[0], qualities[1], qualities[2], qualities[3], qualities[4], qualities[5]);
                        }
                    }while(lines != null);
                    reader.close();
                    JOptionPane.showMessageDialog(null, "Racer Import has completed!", "Import", JOptionPane.PLAIN_MESSAGE);
                }catch(IOException e){
                   JOptionPane.showMessageDialog(null, "This file can't be imported."
                           + "\nPlease verify the file matches the Racer Template.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            catch(FileNotFoundException e){
                System.out.println("There was an extreme error.");
            }
            
            System.out.println("\nAMOUNT OF REGISTERED RACERS: " + racers.size() + "\n");
    }
    public void addRacer(String lName, String fName, String bibNum, String gender, String age, String race)
    {
        Racer tempRacer = new Racer();
        tempRacer.setFirstName(fName);
        tempRacer.setLastName(lName);
        tempRacer.setAge(age);
        tempRacer.setRaceType(race);
        tempRacer.setBibNum(bibNum);
        tempRacer.setGender(gender);
        racers.add(tempRacer);
    }
    
    public void addRacerWithTime(String lName, String fName, String bibNum, String gender, String age, String race, RaceTime time)
    {
        Racer tempRacer = new Racer();
        tempRacer.setFirstName(fName);
        tempRacer.setLastName(lName);
        tempRacer.setAge(age);
        tempRacer.setRaceType(race);
        tempRacer.setBibNum(bibNum);
        tempRacer.setGender(gender);
        tempRacer.setTime(time);
        racers.add(tempRacer);
    }
    
    public Object[][] getTimesStringArray()
    {
        Object[][] toReturn = new Object[times.size()][3];
        
        for(int i = 0; i < times.size(); i++)
        {
            toReturn[i][0] = "" + (i+1);
            toReturn[i][1] = times.get(i).getDoubleStringTime();
            toReturn[i][2] = "";
        }
        System.out.print("JACKSON: " + toReturn[0][0]);
//        for(int k = 0; k < times.size(); k++)
//        {
//            toReturn[1][k] = "";
//        }
        return toReturn;
    }
    

    //Assign times to each racer within the racer array. 
    public void addTimesToRacers()
    {
        //This method will assign times to all of the racers. This way we can sort by place, as well as by gender, age, and race.
        JOptionPane.showMessageDialog(null, "We are currently apending the times to racers. Click okay to begin.", "Complete/Save", JOptionPane.INFORMATION_MESSAGE);
        
        boolean flag = true;      

                //If our registration is empty insert racers into the racers array. 
                //CODE: 0001
            	if(racers.size() == 0)
            	{
                    for(int k = 0; k < bibNums.size(); k++)
                    {
                            System.out.println("Adding new racer into the list. CODE: 0001");
                            //String lName, String fName, String bibNum, String gender, String age, String race
                            addRacerWithTime("RACER", "BANDIT", bibNums.get(k), "N/A", "0", "DEFAULT", times.get(k));
                            //writer.write(k+1 + ",");
                            //writer.write(times.get(k).getDoubleStringTime()+ ",");
                            //writer.write("BANDIT,");
                            //writer.write("RACER,");
                            //writer.write(bibNums.get(k) + ",");
                            //writer.write("N/A,");
                            //writer.write("N/A,\r");
                    }

            	}
            	else{
                    boolean flagger;
            		for(int i = 0; i < bibNums.size(); i ++)
                        {
                            flagger = false;
     	            	//String firstLast = racers.get(i).getFirstName() + " " + racers.get(i).getLastName();
                            for(int j = 0; j < racers.size(); j++)
                            {
                                
                                if(racers.get(j).getBibNum().equals(bibNums.get(i)))
                                {
                                    //Racer was found in the list. We will add its time. 
                                    //CODE: 0010

                                        System.out.println("Found Racer, setting time. CODE 0010");
                                        racers.get(j).setTime(times.get(i));
                                        flagger = true;
                                        //Why is this next line here?
                                        //flag = false;
                                }
                            }
                                if(!flagger)
                                {
                                    //If our registration is empty insert racers into the racers array. 
                                    //CODE: 0001
                                    System.out.println("Adding new racer into the list. CODE: 0001");
                                    //String lName, String fName, String bibNum, String gender, String age, String race
                                    addRacerWithTime("RACER", "BANDIT", bibNums.get(i), "N/A", "0", "DEFAULT", times.get(i));
                                    //writer.write(k+1 + ",");
                                    //writer.write(times.get(k).getDoubleStringTime()+ ",");
                                    //writer.write("BANDIT,");
                                    //writer.write("RACER,");
                                    //writer.write(bibNums.get(k) + ",");
                                    //writer.write("N/A,");
                                    //writer.write("N/A,\r");    
                                }
                            
                        
                            //else if(firstLast.equals(bibNums.get(k)))
                            //{
                            //        System.out.println("Hit 2");
                            //        writer.write(i+1 + ",");
                            //        writer.write(times.get(k).getDoubleStringTime()+ ",");
                            //        writer.write(racers.get(i).getLastName() + ",");
                            //        writer.write(racers.get(i).getFirstName() + ",");
                            //        writer.write(racers.get(i).getBibNum() + ",");
                            //        writer.write(racers.get(i).getAge() + ",");
                            //        writer.write(racers.get(i).getRaceType() + ",\r");
                            //
                            //        flag = false;
                            //}
                            
                        } 
                    System.out.println("HIT END OF LOOP");
	            }
            
    }
    
    //This method will allow us to save the results (that are currently now stored in the racers array) by time.
    public void sortResultsByPlace()
    {
        JOptionPane.showMessageDialog(null, "We are now going to sort results based on place.", "Complete/Save", JOptionPane.INFORMATION_MESSAGE);
            //Create a temporary array.
            List<Racer> temp = new ArrayList<Racer>();
            int currentPosition;
            System.out.println("Racers size at beginning: " + racers.size());
            
            while(racers.size() > 2)
            {
                currentPosition = 0;
                
                try
                {
                    for(int i = 1; i < racers.size(); i++)
                
                    
                    if(racers.get(currentPosition).getDoubleTime() > racers.get(i).getDoubleTime())
                    {
                        System.out.println("Found smaller item");

                        currentPosition = i;
                    }
                    else
                    {
                        System.out.println("Trying loop again.");
                    }
                
                //Add racer to new list
                temp.add(racers.get(currentPosition));
                
                //Set Place of Racer
                //Integer tempLocation = temp.size() - 1;
                //temp.get(tempLocation).setPlace(tempLocation.toString());
                
                //Remove racer from old list
                racers.remove(currentPosition);
                
                System.out.println("Racers size: " + racers.size());
            
            if(racers.size() == 2)
            {
                if(racers.get(0).getLongTime() > racers.get(1).getLongTime())
                {
                    temp.add(racers.get(1));
                    temp.add(racers.get(0));
                    
                    
                    racers.clear();
                }
                else
                {
                    temp.add(racers.get(0));
                    temp.add(racers.get(1));
                    
                    
                    racers.clear();
                }
                
            }
            
            
            
            
            
            
            //CODE: 1199 - this isn't properly working yet.
            else if(racers.size() == 1)
            {
                System.out.println("I hit a list of only one racers. I will automatically add this racer. CODE: 1199");
                temp.add(racers.get(0));
                racers.clear();
            }
            else
                {
                System.out.println("THERE WAS AN EXTREME ERROR. Please note that sorting racers cannot be done without racers!");
                System.out.println("THERE WAS AN EXTREME ERROR. Please note that sorting racers cannot be done without racers!");
                System.out.println("THERE WAS AN EXTREME ERROR. Please note that sorting racers cannot be done without racers!");
                System.out.println("THERE WAS AN EXTREME ERROR. Please note that sorting racers cannot be done without racers!");
                //System.exit(1);
            }
            
        }catch(java.lang.NullPointerException e)
        {
            System.out.println("This racer did not race. Racer will be deleted");
            racers.remove(currentPosition);
        }
            }  
                
                System.out.println("The size of the racers array is now: " + racers.size());
                racers = temp;
                System.out.println("The size of the sorted racers array is now: " + racers.size());
            
    }
    public void saveCombinedResults()
    {
        //Prompt user to let them know we are starting the save process. 
            JOptionPane.showMessageDialog(null, "We are now going to save ALL results.", "Complete/Save", JOptionPane.INFORMATION_MESSAGE);
        try
        {
            name = JOptionPane.showInputDialog(null, "Please enter the name of the race:", "Race Information", JOptionPane.QUESTION_MESSAGE);
            date = JOptionPane.showInputDialog(null, "Please enter the date of the race:", "Race Information", JOptionPane.QUESTION_MESSAGE);
            
            System.out.println("Saving Data.");
        JFileChooser chooser = new JFileChooser();
        File results = null;
        boolean flag = true;            
            
            do
            {
               if(chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
               {
                   results = chooser.getSelectedFile();
                   File tempFile = new File(results.toString()+".csv");
                   results = tempFile;
                   flag = false;
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "You must select a destination.", "Saving File", JOptionPane.ERROR_MESSAGE);
               }
            }while(flag);
            FileWriter fileout = new FileWriter(results);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            System.out.println("I'm ready!");
            
            writer.write(name + " (" + date + ") Results\n");
            writer.write("Results created by RaceReg2.0\n");
            writer.write("http://racereg.jimdo.com\n");
            
            writer.write("Place,");
            writer.write("Time,");
            writer.write("Last Name,");
            writer.write("Last Name,");
            writer.write("Bib Number");
            writer.write("Gender,");
            writer.write("Age,");
            writer.write("Race,\r");
            
            flag = true;
            //Used to set the place of the racer
            Integer place;
            
            for(int i = 0; i < racers.size(); i++)
            {
                place = i + 1;
                
                //Set Place in the Racer object
                racers.get(i).setPlace(place.toString());
                
                writer.write(place + ",");
                writer.write(racers.get(i).getDoubleStringTime()+ ",");
                writer.write(racers.get(i).getLastName() + ",");
                writer.write(racers.get(i).getFirstName() + ",");
                writer.write(racers.get(i).getBibNum() + ",");
                writer.write(racers.get(i).getGender() + ",");
                writer.write(racers.get(i).getAge() + ",");
                writer.write(racers.get(i).getRaceType() + ",\r");
            }
	            
            
            writer.close();
        }catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
    }
    
    public void saveResultsByGender()
    {              
        List<Racer> male = new ArrayList<Racer>();
        List<Racer> female = new ArrayList<Racer>();
        List<Racer> other = new ArrayList<Racer>();
        
        for(int i = 0; i < racers.size(); i++)
        {
            if(racers.get(i).getGender().equals("M") || racers.get(i).getGender().equals("m") || racers.get(i).getGender().equals("Male") || racers.get(i).getGender().equals("male"))
            {
                male.add(racers.get(i));
            }
            else if(racers.get(i).getGender().equals("F") || racers.get(i).getGender().equals("f") || racers.get(i).getGender().equals("Female") || racers.get(i).getGender().equals("female"))
            {
                female.add(racers.get(i));
            }
            else
            {
                other.add(racers.get(i));
            }
        }
        
        if(!other.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By The <<Other>> Gender", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(other, "Other");
        }
        if(!male.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By The <<Male>> Gender", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(male, "Male");
        }
        if(!female.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By The <<Female>> Gender", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(female, "Female");
        }
    }
        
        public void saveResultsByAge()
    {              
        List<Racer> under13 = new ArrayList<Racer>();
        List<Racer> under18 = new ArrayList<Racer>();
        List<Racer> under50 = new ArrayList<Racer>();
        List<Racer> over49 = new ArrayList<Racer>();
        
        for(int i = 0; i < racers.size(); i++)
        {
            int age = Integer.parseInt(racers.get(i).getAge());
            
            if(age < 13)
            {
                under13.add(racers.get(i));
            }
            else if(age < 18)
            {
                under18.add(racers.get(i));
            }
            else if(age < 50)
            {
                under50.add(racers.get(i));
            }
            else
            {
                over49.add(racers.get(i));
            }
        }
        
        if(!under13.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By the age of 12 or younger", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(under13, "Under 13");
        }
        if(!under18.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By the age of 17 or younger", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(under18, "Under 17");
        }
        if(!under50.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By the age of 49 or younger", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(under50, "Under 50");
        }
        if(!over49.isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Saving Results By the age of 50 & Older", "Results Sort", JOptionPane.INFORMATION_MESSAGE);
            saveListedResults(under50, "50+");
        }
        
    }
        
        public void saveListedResults(List<Racer> r, String sort)
    {
        try
        {
            //String name = JOptionPane.showInputDialog(null, "Please enter the name of the race:", "Race Information", JOptionPane.QUESTION_MESSAGE);
            //String date = JOptionPane.showInputDialog(null, "Please enter the date of the race:", "Race Information", JOptionPane.QUESTION_MESSAGE);
            
            System.out.println("Saving Data for: " + sort + " sort.");
        JFileChooser chooser = new JFileChooser();
        File results = null;
        boolean flag = true;            
            
            do
            {
               if(chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
               {
                   results = chooser.getSelectedFile();
                   File tempFile = new File(results.toString()+".csv");
                   results = tempFile;
                   flag = false;
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "You must select a destination.", "Saving File", JOptionPane.ERROR_MESSAGE);
               }
            }while(flag);
            FileWriter fileout = new FileWriter(results);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            System.out.println("I'm ready!");
            
            writer.write(name + ": " + sort + " Sort" + " (" + date + ") Results\n");
            writer.write("Results created by RaceReg2.0\n");
            writer.write("http://racereg.jimdo.com\n");
            
            writer.write("Place,");
            writer.write("Time,");
            writer.write("Last Name,");
            writer.write("Last Name,");
            writer.write("Bib Number,");
            writer.write("Gender,");
            writer.write("Age,");
            writer.write("Race,\r");
            
            flag = true;
      
            for(int i = 0; i < r.size(); i++)
            {
                //writer.write(i+1 + ",");
                writer.write(r.get(i).getPlace()+ ",");
                writer.write(r.get(i).getDoubleStringTime()+ ",");
                writer.write(r.get(i).getLastName() + ",");
                writer.write(r.get(i).getFirstName() + ",");
                writer.write(r.get(i).getBibNum() + ",");
                writer.write(r.get(i).getGender() + ",");
                writer.write(r.get(i).getAge() + ",");
                writer.write(r.get(i).getRaceType() + ",\r");
            }
	            
            
            writer.close();
        }catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
		
		
        
    }

    public void addBibNums(ArrayList<String> bN)
    {
        bibNums = bN;
    }
            
    public void compileTable(ArrayList<String> bN) {
        addBibNums(bN);
        addTimesToRacers();
        sortResultsByPlace();
        saveCombinedResults();
        saveResultsByGender();
        saveResultsByAge();
        JOptionPane.showMessageDialog(null, "Results have been saved as a CSV"
                + " file.\nYou can open this file with Notepad, or a Spreadsheet"
                + " editor. Timer will now close.", "Save Complete",JOptionPane.INFORMATION_MESSAGE);
        window.setVisible(false);
    }
    
    int getSize() {
        return times.size();
    }
}

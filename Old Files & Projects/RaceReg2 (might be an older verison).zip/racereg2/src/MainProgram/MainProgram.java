/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainProgram;
 
import Timer.*;
/**
 *
 * @author Jackson Porter
 * @version 1.0
 */
public class MainProgram {
    public static ProgramChooser chooseProgramWin;
    
    public static void launchTimer()
    {
        TimerProgram timer = new TimerProgram();
        chooseProgramWin.setVisible(false);
    }
    
    public static void main(String[]args)
    {
        System.out.println("Setting Icon for Program");
        
        
        
        System.out.println("Starting Combined Program!");
        chooseProgramWin = new ProgramChooser();
        chooseProgramWin.setVisible(true);
    }
}

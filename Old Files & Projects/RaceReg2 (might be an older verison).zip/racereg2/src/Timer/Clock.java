package Timer;

import java.awt.event.*;
import javax.swing.*;
/**
 * Write a description of class ClockWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Clock extends JComponent
{
    private Number hr1, hr2;
    private Number min1, min2, sec1, sec2;
    private Colon hrColon, minColon;

    /**
     * Constructor for objects of class ClockWin
     */
    public Clock(int x, int y)
    {
        this.setBounds(x, y, 1415, 600);
        
        hr1 = new Number(0, 0, 0);
        hr2 = new Number(0, 0, 0);
        min1 = new Number(0, 0, 0);
        min2 = new Number(350, 0, 0);
        sec1 = new Number(765, 0, 0);
        sec2 = new Number(1115, 0, 0);
        
        //this.add(hr1, 0);
        //this.add(hr2, 0);
        this.add(min1, 0);
        this.add(min2, 0);
        this.add(sec1, 0);
        this.add(sec2, 0);
        
        hrColon = new Colon(320, 0);
        minColon = new Colon(670, 0);
        //this.add(hrColon, 0);
        this.add(minColon, 0);
        
        this.repaint();
    }
    
    
    public void addSecond(int seconds, int minutes, int hours)
    {
        int ones, tens, minutes1, minutes2, hours1, hours2;
        
        //Hours Conversion:
        hours = seconds / 3600;
        
        hours1 = (hours % 100) / 10;
        hr1.setNumber(hours1);
        
        hours2 = hours % 10;
        hr2.setNumber(hours2);
        
        seconds -= (hours * 3600);
        //System.out.println("TS1: " + seconds);
        
        //Minutes Conversion:
        minutes = seconds / 60;
        
        minutes1 = (minutes % 100) / 10;
        min1.setNumber(minutes1);

        minutes2 = minutes % 10;
        min2.setNumber(minutes2);
        
        seconds -= (minutes * 60);

        
        //Seconds Conversion:
        tens = (seconds % 100) / 10;
        sec1.setNumber(tens);
        
        ones = seconds % 10;
        sec2.setNumber(ones);
        
        seconds -= seconds;

        this.repaint();
    }
    
    public String returnTimeString()
    {
        return hr1.getNumber() + hr2.getNumber() + ":" + min1.getNumber() + 
                min2.getNumber() + ":" + sec1.getNumber() + sec2.getNumber();
    }
}

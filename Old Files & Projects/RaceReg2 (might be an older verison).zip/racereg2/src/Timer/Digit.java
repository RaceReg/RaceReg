package Timer;



import javax.swing.*;
/**
 * Creates a rectangular digit (8) object that can be added to a window. 
 * 
 * @author Jackson Porter
 * @version Jan 29th, 2015
 */
public class Digit extends JComponent
{
	//int x, y;
	protected Rectangle top, middle, bottom, topLeft, topRight, bottomLeft, bottomRight;
	
	/**
	 * Creates a digit by instantiating Rectangle objects (displays an eight (8) by default).
	 * @param x X coordinate for Digit object.
	 * @param y Y coordinate for Digit object.
	 */
	public Digit(int x, int y)
	{
		this.setBounds(x, y, 300, 500);
		
		top = new Rectangle(50, 0, 200, 75);
		this.add(top, 0);
		
		middle = new Rectangle(50, 215, 200, 75);
		this.add(middle, 0);
		
		bottom = new Rectangle(50, 425, 200, 75);
		this.add(bottom, 0);
		
		topLeft = new Rectangle(0, 0, 50, 250);
		this.add(topLeft, 0);
		
		topRight = new Rectangle(250, 0, 50, 250);
		this.add(topRight, 0);
		
		bottomLeft = new Rectangle(0, 250, 50, 250);
		this.add(bottomLeft, 0);
		
		bottomRight = new Rectangle(250, 250, 50, 250);
		this.add(bottomRight, 0);
	}
	
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Timer;

/**
 *
 * @author Jackson Porter - RaceReg Developer
 * @version 1.0
 */
public class TimerMain {
    public static void main(String[]args)
    {
        System.out.println("Starting Timer!");
        TimerProgram program = new TimerProgram();
    }
}

package Timer;

/**
 * Creates a digit that displays only the rectangles corresponding with a specific number. 
 * 
 * @author Jackson Porter
 * @version Jan 29th, 2015
 */
public class Number extends Digit{
	private int currentNumber;
	
	/**
	 * Creates a Number object by setting its position, and calling drawNumber() with the given number to draw the number.
	 * 
	 * @param x X coordinate for number object.
	 * @param y Y coordinate for number object.
	 * @param num Number to be displayed.
	 */
		public Number(int x, int y, int num)
		{
			super(x, y);
			this.setNumber(num);
		}
		/**
		 * Displays only the rectangles needed for the given number.
		 * @param num Number to be drawn.
		 */
		public void drawNumber()
		{
			switch(currentNumber){
        		case 0:
        			showAll();
        			middle.setVisible(false);
        			break;
        		case 1:
        			hideAll();
        			topRight.setVisible(true);
        			bottomRight.setVisible(true);
        			break;
        		case 2:
        			showAll();
        			topLeft.setVisible(false);
        			bottomRight.setVisible(false);
        			break;
        		case 3:
        			showAll();
        			topLeft.setVisible(false);
        			bottomLeft.setVisible(false);
        			break;
        		case 4:
        			showAll();
        			top.setVisible(false);
        			bottom.setVisible(false);
        			bottomLeft.setVisible(false);
        			break;
        		case 5:
        			showAll();
        			topRight.setVisible(false);
        			bottomLeft.setVisible(false);
        			break;
        		case 6:
        			showAll();
        			topRight.setVisible(false);
        			break;
        		case 7:
        			hideAll();
        			top.setVisible(true);
        			topLeft.setVisible(true);
        			topRight.setVisible(true);
        			bottomRight.setVisible(true);
        			break;
        		case 8:
        			showAll();
        			break;
        		case 9:
        			showAll();
        			bottomLeft.setVisible(false);
        			break;
			}
		}
		/**
		 * Shows all of the rectangles (in the digit).
		 */
		private void showAll()
		{
			top.setVisible(true);
			middle.setVisible(true);
			bottom.setVisible(true);
			topLeft.setVisible(true);
			topRight.setVisible(true);
			bottomLeft.setVisible(true);
			bottomRight.setVisible(true);
			
		}
		/**
		 * Hides all of the rectangles (in the digit).
		 */
		private void hideAll()
		{
			top.setVisible(false);
			middle.setVisible(false);
			bottom.setVisible(false);
			topLeft.setVisible(false);
			topRight.setVisible(false);
			bottomLeft.setVisible(false);
			bottomRight.setVisible(false);
		}
		
		/**
		 * Takes a desired number and sets it as the currentNumber, it also calls drawNumber() to automatically generate the corresponding digit. 
		 * @param i Desired number to be created.
		 */
		public void setNumber(int i)
		{
		    currentNumber = i;
			drawNumber();
		}
		
		/**
		 * Returns the desired number to be drawn.
		 * @return Value of the desired number to drawn.
		 */
		public int getNumber()
		{
			return currentNumber;
		}
}

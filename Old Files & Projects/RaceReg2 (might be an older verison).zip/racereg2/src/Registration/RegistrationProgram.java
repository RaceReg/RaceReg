/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Registration;

import Racer.Racer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Jackson Porter
 * @version 1.0
 */
public class RegistrationProgram {
    RegistrationWindow mainWin;
    NewRacerForm racerWin;
    private List<Racer> racers;
    boolean slaveProgram;
    String[] importReqs;
    RacersDisplay displayWin;
    final String TABS = "Last Name\tFirst Name\tBib Number\tGender\tAge\tRace\n";
    RacerDisputeWin disputeWin;
    boolean disputeSettled;
    
    public RegistrationProgram()
    {
        mainWin = new RegistrationWindow(this);
        racerWin = new NewRacerForm(this);
        mainWin.setVisible(true);
        
        
        System.out.println("Ready!");
        racers = new ArrayList<Racer>();
        slaveProgram = false;
        
        importReqs = new String[5];
        importReqs[0] = "DO NOT DELETE THESE FIRST FIVE LINES.,,,,,";
        importReqs[1] = "Type in Racer Information under the columns below.,,,,,";
        importReqs[2] = "The only required field is the Bib Number field.,,,,,";
        importReqs[3] = ",,,,,";
        importReqs[4] = "Last Name,First Name,Bib Number,Gender,Age,Race,,,,,";
        
        displayWin = new RacersDisplay(this);
        updateWindow();
        //displayWin.setText(TABS);
    }
    
    public void getNewRacer()
    {
        racerWin.setVisible(true);
        racerWin.clearFields();
    }
    
    public void showRegistration(boolean v)
    {
        displayWin.setVisible(v);
    }
    
    public void addRacer(String lName, String fName, String bibNum, String gender, String age, String race)
    {
        Racer tempRacer = new Racer();
        tempRacer.setFirstName(fName);
        tempRacer.setLastName(lName);
        tempRacer.setAge(age);
        tempRacer.setRaceType(race);
        tempRacer.setBibNum(bibNum);
        tempRacer.setGender(gender);
        racers.add(tempRacer);
        //System.out.println(fName + " " + lName + " " + age + " " + race);
        updateWindow();
        scanForErrors();
    }
    
    public void saveRacers()
    {
        System.out.println("ATTEMPTING REGISTRATION SAVE!");
        JFileChooser chooser = new JFileChooser();
        File saveFile = null;
        boolean flag = true;
        
    	try
        {
            do
            {
               if(chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
               {
                   saveFile = chooser.getSelectedFile();
                   File tempFile = new File(saveFile.toString()+".csv");
                   saveFile = tempFile;
                   flag = false;
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "You must select a destination.", "Saving File", JOptionPane.ERROR_MESSAGE);
               }
            }while(flag);
            
            FileWriter fileout = new FileWriter(saveFile);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            writer.write("DO NOT DELETE THESE FIRST FIVE LINES.,,,,,\r");
            writer.write("Type in Racer Information under the columns below.,,,,,\r");
            writer.write("The only required field is the Bib Number field.,,,,,\r");
            writer.write(",,,,,\r");
            writer.write("Last Name,First Name,Bib Number,Gender,Age,Race,,,,,\r");
            
            
            for(int i = 0; i < racers.size(); i ++)
            {
                writer.write(racers.get(i).getLastName() + ",");
                writer.write(racers.get(i).getFirstName() + ",");
                writer.write(racers.get(i).getBibNum() + ",");
                writer.write(racers.get(i).getGender() + ",");
                writer.write(racers.get(i).getAge() + ",");
                writer.write(racers.get(i).getRaceType() + ",\r");
                //writer.write(racers.get(i).getRaceType() + "END LINE,\r");
            }
            writer.close();
        }catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
        
        JOptionPane.showMessageDialog(null, "Save Complete.", "File Saved.", JOptionPane.PLAIN_MESSAGE);
        if(slaveProgram)
        {
            System.exit(0);
        }
    }
    	public void importRacers()
        {
        boolean skip = false;
        
        if(racers.size() > 0)
        {
            String temp = JOptionPane.showInputDialog(null, "You are about to add racers ALONGSIDE your current entries. Type '1' to proceed, '2' to overwrite and '3' to cancel.", "Import", JOptionPane.INFORMATION_MESSAGE);
            if(temp.equals("1"))
            {
                skip = false;
            }
            if(temp.equals("2"))
            {
                racers.clear();
                skip = false;
            }
            if(temp.equals("3"))
            {
                 skip = true;
            }
        }
        else
        {
            skip = false;
        }
        
        if(skip)
        {
            JOptionPane.showMessageDialog(null, "No changes were made.", "Racer Import", JOptionPane.PLAIN_MESSAGE);
        }
        else
        {
            JFileChooser chooser = new JFileChooser();
            File importFile = null;
            //Importing acutally begins here. 
            try{
                
                 boolean retry = true;
            do{
            if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                importFile = chooser.getSelectedFile();
                retry = false;
            }
            else
                JOptionPane.showMessageDialog(null, "You selected no file. You must select a file.", "Error", JOptionPane.ERROR_MESSAGE);
            }while(retry);
        
                FileReader filein = new FileReader(importFile);
                BufferedReader reader = new BufferedReader(filein);
 
                String lines = "";
                    try{
                        for(int i = 0; i < 5; i++)
                        {
                            String temp = reader.readLine();
                            System.out.println(temp);
                            System.out.println(importReqs[i]);
                            if(temp.equals(importReqs[i]))
                            {
                                
                                System.out.println("Line " + i + " is correct.");
                            }
                            else
                            {
                                throw new IOException();
                            }
                        }
                    
                    do{
                        System.out.println("HIT READER.");
                        lines = reader.readLine();
                        System.out.println("Current Line: " + lines);
                        if(lines!= null){
                            String [] qualities = lines.split(",");
                            for(int i = 0; i < qualities.length; i++)
                            {
                                System.out.println(i + ": " + qualities[i]);
                            }
                            
                            //String fName, String lName, String age, String race, String bibNum, String gender
                            //first name, last name, bib number, age, gender, race
                            addRacer(qualities[0], qualities[1], qualities[2], qualities[3], qualities[4], qualities[5]);
                        }
                    }while(lines != null);
                    reader.close();
                    JOptionPane.showMessageDialog(null, "Racer Import has completed!", "Import", JOptionPane.PLAIN_MESSAGE);
                }catch(IOException e){
                   JOptionPane.showMessageDialog(null, "This file can't be imported."
                           + "\nPlease verify the file matches the Racer Template.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            catch(FileNotFoundException e){
                System.out.println("There was an extreme error.");
            }
        }
        updateWindow();
    }

    void updateWindow() {
        String compile = TABS;
        for(int i = 0; i < racers.size(); i++)
        {
            compile += racers.get(i).toString() + "\n";
            System.out.println(racers.get(i).toString() + "\n");
        }
        
        mainWin.setRegistrationText(compile);
        mainWin.setRegistrationNumber(racers.size());
        displayWin.setText(compile);
        displayWin.setNumOfRacers(racers.size());
    }

    //void deleteRacer(String temp)
    //{
        //deleteWindow.setVisible();
    //}
    void deleteRacer(String temp) {
        int toDelete = -1;
        int count = 0;
        for(int i = 0; i < racers.size(); i++)
        {
            if(racers.get(i).getBibNum().equals(temp))
            {
                toDelete = i;
                count++;
            }
        }
        if(toDelete != -1 && count == 1)
        {
            racers.remove(toDelete);
        }
        else if(count > 1)
        {
            JOptionPane.showMessageDialog(null, "THERE ARE TWO RACERS WITH THE SAME BIB NUMBER. Please use the Delete By Name Feature!", "Delete", JOptionPane.ERROR_MESSAGE);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Racer could not be found!", "Delete", JOptionPane.ERROR_MESSAGE);
        }
        updateWindow();
    }

    void editRacer(String temp) {
        JOptionPane.showMessageDialog(displayWin, "We must scan for errors in the registry before you can edit a racer. Click OK to continue.", "Edit Racer", JOptionPane.INFORMATION_MESSAGE);
        scanForErrors();
        
        int k = 0;
        JOptionPane.showMessageDialog(displayWin, "We have loaded this Racer's Information. Please click save when completed.", "Edit Racer", JOptionPane.INFORMATION_MESSAGE);
        boolean terminate = false;
        for(int i = 0; !terminate; i++)
        {
            if(racers.get(i).getBibNum().equals(temp))
            {
                terminate = true;
                k = i;
            }
        }
        if(!terminate)
        {
            JOptionPane.showMessageDialog(displayWin, "Sorry, this racer was not found.", "Racer Not Found", JOptionPane.INFORMATION_MESSAGE);
        }
        else
        {
           racerWin.setFields(racers.get(k)); 
           racerWin.setEditButton(racers.get(k).getBibNum());
           racerWin.setVisible(true);
        }
        
    }

    void scanForErrors() {
        if(!disputeSettled)
        {
            JOptionPane.showMessageDialog(mainWin, "The Program will now check for conflicting entries.", "Error Checking", JOptionPane.INFORMATION_MESSAGE);
        }
        
        
        boolean breakout = false;
        
        String currentBib = "";        
        for(int r = 0; r < racers.size() && !breakout; r++)
        {
            System.out.println("HIT 1");
            currentBib = racers.get(r).getBibNum();
            for(int m = r + 1; m < racers.size() && !breakout; m++)
            {
                System.out.println("HIT 2");
                if(currentBib.equals(racers.get(m).getBibNum()))
                {
                    settleDispute(r, m);
                    breakout = true;
                }
                else
                {
                    System.out.println("NO ERRORS FOUND ON ROUND " + r + "," + m);
                }
            }
            
        }
        
        if(!breakout)
        {
            JOptionPane.showMessageDialog(mainWin, "ALL ENTRIES OK!", "Error Checking", JOptionPane.INFORMATION_MESSAGE);
            disputeSettled = false;
        }
        
        
    }
    void settleDispute(int first, int second)
    {
        disputeWin = new RacerDisputeWin(this);   
        disputeWin.setVisible(true);
        disputeWin.setRacers(racers.get(first), racers.get(second), first, second);
    }


    void fixDispute(int location1, String fix1, int location2, String fix2) {
       Racer tempracer = racers.get(location1);
       tempracer.setBibNum(fix1);
       racers.set(location1, tempracer);
       
       tempracer = racers.get(location2);
       tempracer.setBibNum(fix2);
       racers.set(location2, tempracer);
       
       updateWindow();
       disputeSettled = true;
       scanForErrors();
    }

}

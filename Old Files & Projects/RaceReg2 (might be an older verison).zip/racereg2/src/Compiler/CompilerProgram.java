/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Compiler;

import Racer.Racer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author racer
 */
public class CompilerProgram {
    private CompilerWindow window;
    private ResultsWindow resultsWindow;
    String[] importReqs;
    private List<Racer> racers;
    private boolean registrationImported;
    private boolean timesImported;
    private boolean bibsCompiled;
    
    public CompilerProgram()
    {
        window = new CompilerWindow(this);
        window.setVisible(true);
        
        resultsWindow = new ResultsWindow();
        resultsWindow.setVisible(true);
        
        importReqs = new String[5];
        importReqs[0] = "DO NOT DELETE THESE FIRST FIVE LINES.,,,,,";
        importReqs[1] = "Type in Racer Information under the columns below.,,,,,";
        importReqs[2] = "The only required field is the Bib Number field.,,,,,";
        importReqs[3] = ",,,,,";
        importReqs[4] = "Last Name,First Name,Bib Number,Gender,Age,Race,,,,,";
        
        racers = new ArrayList<Racer>();
        
        registrationImported = false;
        timesImported = false;
        bibsCompiled = false;
        
    }
    
    public boolean bibReady()
    {
        if(registrationImported && timesImported)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean grinderReady()
    {
        if(registrationImported && timesImported && bibsCompiled)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void importRegistration()
    {
       JOptionPane.showMessageDialog(window, "Please select the Registration CSV file.", "Import Times", JOptionPane.INFORMATION_MESSAGE);
       int input = -3;
           JFileChooser chooser = new JFileChooser();
            File importFile = null;
            //Importing acutally begins here. 
            try{
                
                 boolean retry = true;
            do{
            if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
            {
                importFile = chooser.getSelectedFile();
                retry = false;
            }
            else
                input = JOptionPane.showConfirmDialog(null, "You selected no file. Click OK to select a file.", "No File Selected", JOptionPane.OK_CANCEL_OPTION);
                if(input == 2)
                {
                    return;
                }
                //System.out.println("USER SELECTED: " + input);
            }while(retry);
        
                FileReader filein = new FileReader(importFile);
                BufferedReader reader = new BufferedReader(filein);
 
                String lines = "";
                    try{
                        for(int i = 0; i < 5; i++)
                        {
                            String temp = reader.readLine();
                            System.out.println(temp);
                            System.out.println(importReqs[i]);
                            if(temp.equals(importReqs[i]))
                            {
                                
                                System.out.println("Line " + i + " is correct.");
                            }
                            else
                            {
                                throw new IOException();
                            }
                        }
                    
                    do{
                        lines = reader.readLine();
                        System.out.println("Current Line: " + lines);
                        if(lines!= null){
                            String [] qualities = lines.split(",");
                            for(int i = 0; i < qualities.length; i++)
                            {
                                System.out.println(i + ": " + qualities[i]);
                            }
                            //String fName, String lName, String age, String race, String bibNum, String gender
                            //first name, last name, bib number, age, gender, race
                            addRacer(qualities[0], qualities[1], qualities[2], qualities[3], qualities[4], qualities[5]);
                        }
                    }while(lines != null);
                    reader.close();
                    JOptionPane.showMessageDialog(null, "Racer Import has completed!", "Import", JOptionPane.PLAIN_MESSAGE);
                    registrationImported = true;
                    window.setRegistrationImported(true);
                }catch(IOException e){
                   JOptionPane.showMessageDialog(null, "This file can't be imported."
                           + "\nPlease verify the file matches the Racer Template.", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            catch(FileNotFoundException e){
                System.out.println("There was an extreme error.");
            }
            
            
    }
    
    public void addRacer(String lName, String fName, String bibNum, String gender, String age, String race)
    {
        Racer tempRacer = new Racer();
        tempRacer.setFirstName(fName);
        tempRacer.setLastName(lName);
        tempRacer.setAge(age);
        tempRacer.setRaceType(race);
        tempRacer.setBibNum(bibNum);
        tempRacer.setGender(gender);
        racers.add(tempRacer);
    }
}

package Racer;


/**
 * Write a description of class Runner here.
 * 
 * @author Jackson Porter
 * @version 0.01
 */
public class Racer
{
    private String age;
    private String firstName, lastName;
    private String raceType;
    private String bibNum;
    private RaceTime time;
    private String gender;
    private String place;
    
    /**
     * Constructor for objects of class Runner
     */
    public Racer(String n2, String n1, String bN, String gn, String a, String r)
    {
        age = a;
        firstName = n1;
        lastName = n2;
        raceType = r;
        bibNum = bN;
        gender = gn;
    }
    
    public Racer()
    {
        age = "UNKNOWN AGE";
        firstName = "UNKNOWN RACER";
        lastName = "UNKNOWN RACER";
        raceType = "DEFAULT";
        bibNum = "0";
        gender = "";
    }
    
    public void setBibNum(String bN)
    {
        bibNum = bN;
    }
    
    public String getBibNum()
    {
        return bibNum;
    }
    
    public void setAge(String a)
    {
        age = a;
    }
    
    public String getAge()
    {
        return age;
    }
    
    public void setFirstName(String n)
    {
        firstName = n;
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public void setLastName(String n)
    {
        lastName = n;
    }
    
    public String getLastName()
    {
        return lastName;
    }
    
    public void setRaceType(String rt)
    {
        raceType = rt;
    }
    
    public String getRaceType()
    {
        return raceType;
    }
    
    public void setTime(RaceTime rt)
    {
        time = rt;
    }
    
    public Long getLongTime()
    {
        return time.getLongTime();
    }
    
    public Double getDoubleTime()
    {
        return time.getDoubleTime();
    }
    
    public String getDoubleStringTime()
    {
        return time.getDoubleStringTime();
    }
    
    public void setGender(String gn)
    {
        gender = gn;
    }
    
    public String getGender()
    {
        return gender;
    }
    
    public String getPlace()
    {
        return place;
    }
    
    public void setPlace(String p)
    {
        place = p;
    }
    
    public String toString()
    {
        System.out.println("TEST: " + getLastName() + "\t" + getFirstName() + "\t" + getBibNum() + "\t" + getGender() + "\t" + getAge() + "\t" + getRaceType());
        return getLastName() + "\t" + getFirstName() + "\t" + getBibNum() + "\t" + getGender() + "\t" + getAge() + "\t" + getRaceType();
    }
}

/*
 * This file contains the InputWin class - a JFrame object that collects information
 * and data from a user.
 */
package portproj03;

import javax.swing.*;
import java.awt.event.*;
/**
 * The purpose of this class is to provide a graphical window for users to enter
 * data, perform actions, and retrieve data.
 * 
 * @author Jackson Porter
 * @version 9/13/2015
 */
public class InputWin extends JFrame implements ActionListener{
    private JTextField dayField, monthField, yearField;
    private final JButton ADD_DAY, DISPLAY_WORD, DISPLAY_NUMBERS, SET_DATE, EXIT;
    private final JLabel DAY, MONTH, YEAR;
    private Program program;
    
    /**
     * This constructor instantiates all of the objects used in the JFrame as well
     * as defining the JFrame itself.
     * 
     * @param p is the Program object initialized in the main class.*
     */
    public InputWin(Program p)
    {
        //These method calls set up the JFrame.
        super("Menu");
        this.setBounds(100, 100, 500, 500);
        this.setLayout(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        //This sets the window's Program object to the Program object initalized
        //in the main method.
        program = p;
        
        //Day Field & Label
        dayField = new JTextField(1);
        dayField.setBounds(220, 10, 100, 50);
        this.add(dayField, 0);
        
        DAY = new JLabel("Day of the Month (Numerical):");
        DAY.setBounds(10, 10, 200, 50);
        this.add(DAY, 0);
        
        //Month Field & Label
        monthField = new JTextField(1);
        monthField.setBounds(220, 70, 100, 50);
        this.add(monthField, 0);
        
        MONTH = new JLabel("Month (Numerical):");
        MONTH.setBounds(10, 70, 200, 50);
        this.add(MONTH, 0);
        
        //Year Field & Label
        yearField = new JTextField(1);
        yearField.setBounds(220, 130, 100, 50);
        this.add(yearField, 0);
        
        YEAR = new JLabel("Year (Numerical):");
        YEAR.setBounds(10, 130, 200, 50);
        this.add(YEAR, 0);
        
        //Set Date Button
        SET_DATE = new JButton("Set Date");
        SET_DATE.setBounds(20, 220, 200, 50);
        SET_DATE.addActionListener(this);
        this.add(SET_DATE, 0);
        
        //Window Buttons Phase (Part) 2
        //These buttons are used after the user enters an intial date. 
        
        //Add a Day Button
        ADD_DAY = new JButton("Add a Day");
        ADD_DAY.addActionListener(this);
        ADD_DAY.setBounds(20, 20, 200, 50);
        ADD_DAY.setVisible(false);
        this.add(ADD_DAY, 0);
        
        //Display Date in Words Button
        DISPLAY_WORD = new JButton("Display Date in Words");
        DISPLAY_WORD.addActionListener(this);
        DISPLAY_WORD.setBounds(20, 120, 200, 50);
        DISPLAY_WORD.setVisible(false);
        this.add(DISPLAY_WORD, 0);
        
        //Display Date in Numbers button
        DISPLAY_NUMBERS = new JButton("Display Date in Numbers");
        DISPLAY_NUMBERS.addActionListener(this);
        DISPLAY_NUMBERS.setBounds(20, 220, 200, 50);
        DISPLAY_NUMBERS.setVisible(false);
        this.add(DISPLAY_NUMBERS, 0);
        
        //Exit Button
        EXIT = new JButton("Exit");
        EXIT.addActionListener(this);
        EXIT.setBounds(400, 400, 75, 50);
        this.add(EXIT, 0);
        
        //Refresh the JFrame
        this.repaint();
    }
    
    /**
     * This method clears the JTextFields in the JFrame.
     */
    public void reset()
    {
        dayField.setText("");
        monthField.setText("");
        yearField.setText("");
    }

    /**
     * This method hides the objects used to get the initial date and displays
     * the buttons to add a day, and display the date.
     */
    private void setPhaseTwo() {
       SET_DATE.setVisible(false);
       DAY.setVisible(false);
       MONTH.setVisible(false);
       YEAR.setVisible(false);
       
       dayField.setVisible(false);
       monthField.setVisible(false);
       yearField.setVisible(false);
       
       ADD_DAY.setVisible(true);
       DISPLAY_WORD.setVisible(true);
       DISPLAY_NUMBERS.setVisible(true);
    }
    
    /**
     * This method checks to see if user input is in a valid range and sets the 
     * input to the Date object in the Program class.
     */
    public void setIntialDate()
    {
        int dt = 1;
        int mn = 1;
        int yr = 1;
        
        //Checks year input
        try{
            yr = Integer.parseInt(yearField.getText());
        }catch(NumberFormatException e){
            yearField.setText("retry");
        }
        
        //Checks month input
        try{
            mn = Integer.parseInt(monthField.getText());
        }catch(NumberFormatException e){
            monthField.setText("retry");
        }
        
        //Checks date input
        try{
            dt = Integer.parseInt(dayField.getText());
        }catch(NumberFormatException e){
            dayField.setText("retry");
        }
                //These if-statments check to see if the day, month and year
                //combination is legal. If it is not, the user is prompted to 
                //retry.
                if(yr < 1)
                {
                    yearField.setText("retry");                     
                }
                if(mn > 12 || mn < 1)
                {
                    monthField.setText("retry");
                }
                if(dt < 1 || dt > 31)
                {
                    dayField.setText("retry");
                }
                else
                {
                    if(mn == 2)
                    {
                        if(dt > 29)
                        {
                            dayField.setText("retry");
                        }
                        else if((yr % 4) != 0)
                        {
                            if(dt > 28)
                            {
                                dayField.setText("retry");
                            }
                        }
                     }
                    else if(dt > 30)
                    {
                        if(mn == 4 || mn == 6 || mn == 9 || mn == 11)
                        {
                            dayField.setText("retry");
                        }
                    }
                }
                if(dayField.getText().equals("retry"))
                {
                    reset();
                    JOptionPane.showMessageDialog(null, "Incorrect Day of Month Input. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                else if(monthField.getText().equals("retry"))
                {
                    reset();
                    JOptionPane.showMessageDialog(null, "Incorrect Month Input. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                else if(yearField.getText().equals("retry"))
                {
                    reset();
                    JOptionPane.showMessageDialog(null, "Incorrect Year Input. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    program.setInitalDate(new Date(dt, mn, yr));
                    reset();
                    setPhaseTwo();
                }
                
        
       
    }
    
    /**
     * This method detects when a button is clicked and calls the appropriate 
     * method corresponding.
     * @param e is the ActionEvent that occurred.
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()  == ADD_DAY)
        {
           program.addDay(); 
        }
        if(e.getSource() == DISPLAY_WORD)
        {
            program.getWordDate();
        }
        if(e.getSource() == DISPLAY_NUMBERS)
        {
            program.getNumericalDate();   
        }
        if(e.getSource() == SET_DATE)
        {
            setIntialDate();
        }
        if(e.getSource() == EXIT)
        {
            System.exit(0);
        }
    }
    
    
}


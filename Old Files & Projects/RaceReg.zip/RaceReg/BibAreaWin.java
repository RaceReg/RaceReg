import javax.swing.*;
import java.awt.event.*;

import java.util.*;
/**
 * Write a description of class BibAreaWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BibAreaWin extends Window
{
    private JTextArea textArea;
    private JScrollPane scrollArea;
    private JLabel instruct, advise, timeLabel;
    private JLabel [] timePreview;
    
    //private List<RaceTime> times;
    private BibEntry bibEntry;
    
    private boolean complete;
    
    private JButton save;
    /**
     * Constructor for objects of class BibAreaWin
     */
    public BibAreaWin(BibEntry be)
    {
        super("Bib Entry", 0, 0, 500, 700, true);
        
        complete = false;
        bibEntry = be;
                
        instruct = new JLabel("Welcome! Type in each bib number below followed by the Enter key.");
        instruct.setBounds (20, 20, 500, 50);
        this.add(instruct, 0);
        
        advise = new JLabel("Insert entries here:");
        advise.setBounds (100, 65, 500, 50);
        this.add(advise, 0);
                
        textArea = new JTextArea(300, 500);
        textArea.setBounds(100, 100, 300, 500);
        this.add(textArea);
        
        scrollArea = new JScrollPane(textArea);
        //this.add(scrollArea);
        
//         timeLabel = new JLabel("Times Preview:");
//         timeLabel.setBounds(5, 100, 100, 50);
//         this.add(timeLabel, 0);
//         
//         timePreview = new JLabel[20];
//         int placer = 120;
//         times = new ArrayList<RaceTime>();
//         
//         for(int i = 0; i < timePreview.length; i++)
//         {
//             
//             timePreview[i] = new JLabel("Time " + (i + 1) + ": ");
//             timePreview[i].setBounds(5, placer + 10, 100, 50);
//             placer += 40;
//             this.add(timePreview[i], 0);
//         }
        
        save = new JButton("Save and Exit");
        save.setBounds(250, 600, 100, 100);
        save.setVisible(true);
        save.addActionListener(this);
        this.add(save, 0);

        this.repaint();
    }
    
    public void actionPerformed(ActionEvent e)
    {
//         if(e.getSource() == save)
//         {
//             System.out.println("Found!");
//             bibEntry.addBibsToList(getFields(), times.size());
//             bibEntry.exit();
//         }
    }
    
//     public void getTimes(List<RaceTime> t)
//     {
//         times = t;
// //         for(int i = 0; i < timePreview.length; i++)
// //         {
// //             String tempString = t.get(i).getDoubleStringTime();
// //             timePreview[i].setText("Time " + (i + 1) + ": " + tempString);
// //             
// //         }
//     }
    
    public String[] getFields()
    {
        String [] toReturn = textArea.getText().split("\n");
        return toReturn;
    }
}

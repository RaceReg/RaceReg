import java.util.*;
import javax.swing.*;
/**
 * Write a description of class BibEntry here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BibEntry
{
    //private static BibWin bibWin;
    private BibAreaWin window;
    private BibWin window2;
    private List<String> bibNums;
    private int counter;
    private Program program;
    
    //private Program program;
    
    /**
     * Constructor for objects of class BibEntry
     * @param program 
     */
    public BibEntry(Program p)
    {
        //bibWin = new BibWin(this);
        //window = new BibAreaWin(this);
    	
    	program = p;
        window2 = new BibWin(this);
        counter = 1;
        bibNums = new ArrayList<String>();
    }

    public void exit()
    {
    	System.out.println(window2.getBibs());
        program.saveBibsWithTimes(window2.getBibs());
        window2.setVisible(false);
        System.out.println("Successfully exited.");
        
    }
    
    public List<String> getBibs()
    {
        return window2.getBibs();
    }
    
    public void setVisible(boolean v)
    {
        window2.setVisible(v);
        JOptionPane.showMessageDialog(null, "Enter the first 10 racers, then click Next 10 Racers", "Instructions", JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "Once you have finished, click 'Save and Exit'", "Instructions", JOptionPane.INFORMATION_MESSAGE);
    }
    
    

}

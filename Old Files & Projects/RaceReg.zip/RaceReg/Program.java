import java.util.List;
import java.util.ArrayList;
import javax.swing.*;
import java.io.*;


/**
 * This class is the main support of the entire program. All classes report back to this class to report data. 
 * 
 * @author Jackson Porter
 * @version 0.1 9/4/2015s
 */
public class Program
{
    private List<RaceTime> times;
    private List<String> bibNums;
    private Timer timer;
    private InputWindows inputWin;
    private List<String> combinedResults;
    private List<Racer> racers;
    private BibEntry bibEntry;
    private MainWindow window;
    private ImportWin importWin;
    private RegWin regWin;
    
    /**
     * This constructor creates all of the objects (and windows) needed for the program. 
     */
    public Program()
    {
    	//inputWin = new InputWindows(this);
        timer = new Timer(this);
        
        times = new ArrayList<RaceTime>();
        bibNums = new ArrayList<String>();
        racers = new ArrayList<Racer>();
        
        
        combinedResults = new ArrayList<String>();
        
        bibEntry = new BibEntry(this);
        window = new MainWindow(this);
        importWin = new ImportWin(this);
        regWin = new RegWin(this);
        
    }
    
    public void launchTimer()
    {
        JOptionPane.showMessageDialog(null, "This timer is simple. Simply push the 'Lap' button when a racer comes across the line. Make sure someone is keeping track on the the Racer's bib number. If you have a bandit runner - record where they crossed as well.", "Using Timer", JOptionPane.INFORMATION_MESSAGE);
        timer.setToVisible(true);
    }
    public List<RaceTime> getTimes()
    {
    	return times;
    }
    
    public void addTimes(List<RaceTime> t)
    {
    	times = t;
    	try
        {
            FileWriter fileout = new FileWriter("Times.csv");
            BufferedWriter writer = new BufferedWriter(fileout);
            
            writer.write("Time,\r");
    
            
            for(int i = 0; i < times.size(); i ++)
            {
                writer.write(times.get(i).getDoubleStringTime() + ",\r");
            }
            writer.close();
        }
        catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }

        //timerWin.reset();
    	bibEntry.setVisible(true);
    	timer.setToVisible(false);
    }
    
    public void saveBibsWithTimes(List<String> n)
    {
    	bibNums = n;
    	//System.out.println(n + " " + bibNums);
        //System.out.println("SIZE: " + bibNums.size());
        try
        {
        	//System.out.println("IN TRY BLOCK");
            FileWriter fileout = new FileWriter("Bibs-Times.csv");
            BufferedWriter writer = new BufferedWriter(fileout);
            
            writer.write("Name, Time\r");
    
            boolean process = true;
            
            
            for(int i = 0; i < bibNums.size(); i ++)
            {
            	try{
            		//System.out.println("COME:" + bibNums.get(i));
            		//System.out.println("HIT" + times.get(i).getDoubleStringTime());
            			writer.write(bibNums.get(i) + ",");
                        writer.write(times.get(i).getDoubleStringTime());
               }catch(java.lang.IndexOutOfBoundsException e)
            	{
            	   	System.out.println("OUT OF TIMES!");
            	}
            	
            	writer.write(",\r");
            }
            	writer.close();
            	combineAllResults();
        }
        catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
        System.exit(0);
        //timerWin.reset();
    }

	public void bibEntry() {
		bibEntry.setVisible(true);
		
	}

	public void saveRacers()
    {
        System.out.println("ATTEMPTING SAVE!");
        try
        {
            File registration = new File("Registration.csv");
            FileWriter fileout = new FileWriter(registration);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            writer.write("Last Name,");
            writer.write("First Name,");
            writer.write("Bib Number,");
            writer.write("Age,");
            writer.write("Race,\r");
            
            for(int i = 0; i < racers.size(); i ++)
            {
                writer.write(racers.get(i).getLastName() + ",");
                writer.write(racers.get(i).getFirstName() + ",");
                writer.write(racers.get(i).getBibNum() + ",");
                writer.write(racers.get(i).getAge() + ",");
                writer.write(racers.get(i).getRaceType() + ",\r");
            }
            writer.close();
        }
        catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
    }
	
	public void importRacers()
    {
        JOptionPane.showMessageDialog(window, "Welcome to Racer Import! Click Ok to continue.", "Racer Import", JOptionPane.PLAIN_MESSAGE);
        importWin.setVisible(true);
    }


	public void registerRacer() {
		JOptionPane.showMessageDialog(null, "This feature is in beta.", "DEVELOPMENT MESSAGE", JOptionPane.INFORMATION_MESSAGE);
        regWin.setVisible(true);
	}
	
	public void newRacer(String fName, String lName, String age, String race, String bibNum)
    {
        Racer tempRacer = new Racer();
        tempRacer.setFirstName(fName);
        tempRacer.setLastName(lName);
        tempRacer.setAge(age);
        tempRacer.setRaceType(race);
        tempRacer.setBibNum(bibNum);
        racers.add(tempRacer);
        //System.out.println(fName + " " + lName + " " + age + " " + race);
    }
	
	public List<Racer> getRacers()
    {
        return racers;
    }
	
	public void importRacersFile(File f)
    {
        boolean skip = false;
        
        if(racers.size() > 0)
        {
            String temp = JOptionPane.showInputDialog(null, "You are about to add racers ALONGSIDE your current entries. Type '1' to proceed, '2' to overwrite and '3' to cancel.", "Import", JOptionPane.INFORMATION_MESSAGE);
            if(temp.equals("1"))
            {
                skip = false;
            }
            if(temp.equals("2"))
            {
                racers.clear();
                skip = false;
            }
            if(temp.equals("3"))
            {
                 skip = true;
            }
        }
        else
        {
            skip = false;
        }
        
        if(skip)
        {
            JOptionPane.showMessageDialog(null, "No changes were made.", "Racer Import", JOptionPane.PLAIN_MESSAGE);
            importWin.setVisible(false);
        }
        else
        {
            //Importing acutally begins here. 
            
            try{
                FileReader filein = new FileReader(f);
                BufferedReader reader = new BufferedReader(filein);
 
                String lines = "";
                    try{
                    
                    
                    do{
                        lines = reader.readLine();
                        if(lines!= null){
                            String [] qualities = lines.split(",");
                            for(int i = 0; i < qualities.length; i++)
                            {
                                System.out.println(qualities[i]);
                            }
                            newRacer(qualities[0], qualities[1], qualities[3], qualities[4], qualities[2]);
                        }
                    }while(lines != null);
                    reader.close();
                }catch(IOException e){
                    System.out.println("There was an error.");
                }
            }
            catch(FileNotFoundException e){
                System.out.println("There was an extreme error.");
            }
            
        }
        
        JOptionPane.showMessageDialog(null, "Racer Import has completed!", "Import", JOptionPane.PLAIN_MESSAGE);
    }

	public void combineAllResults()
	{
		JOptionPane.showMessageDialog(null, "We are now going to save ALL results.", "Complete/Save", JOptionPane.INFORMATION_MESSAGE);
		
		try
        {
            File results = new File("Results.csv");
            FileWriter fileout = new FileWriter(results);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            System.out.println("I'm ready!");
            
            writer.write("Time,");
            writer.write("Last Name,");
            writer.write("Last Name,");
            writer.write("Bib Number/Name,");
            writer.write("Age,");
            writer.write("Race,\r");
            
            boolean flag = true;
            
            for(int k = 0; k < bibNums.size(); k++)
            {
            	System.out.println("First Loop!");
            	if(racers.size() == 0)
            	{
            		System.out.println("I'm sorry, No Racer Were Entered So There is NO File.");
            	}
            	else{
            		 for(int i = 0; i < racers.size(); i ++)
     	            {
     	            	System.out.println("Second Loop!");
     	            	String firstLast = racers.get(i).getFirstName() + " " + racers.get(i).getLastName();
     	            	if(racers.get(i).getBibNum().equals(bibNums.get(k)))
     	            	{
     	            		System.out.println("Hit 1");
     	            		writer.write(times.get(k).getDoubleStringTime()+ ",");
     	            		writer.write(racers.get(i).getLastName() + ",");
     	            		writer.write(racers.get(i).getFirstName() + ",");
     	            		writer.write(bibNums.get(k)+ ",");
     	            		writer.write(racers.get(i).getAge() + ",");
     		                writer.write(racers.get(i).getRaceType() + ",\r");
     		                
     		                flag = false;
     	            	}
     	            	else if(firstLast.equals(bibNums.get(k)))
     	            	{
     	            		System.out.println("Hit 2");
     	            		writer.write(times.get(k).getDoubleStringTime()+ ",");
     	            		writer.write(racers.get(i).getLastName() + ",");
     	            		writer.write(racers.get(i).getFirstName() + ",");
     	            		writer.write(racers.get(i).getBibNum() + ",");
     	            		writer.write(racers.get(i).getAge() + ",");
     		                writer.write(racers.get(i).getRaceType() + ",\r");
     		                
     		                flag = false;
     	            	}
     	            	else if(flag)
     	            	{
     	            		System.out.println("Hit 3");
     	            		System.out.println(k);
     	            		try{
     	            			writer.write(times.get(k).getDoubleStringTime()+ ",");
     	            		}catch(IndexOutOfBoundsException e)
     	            		{
     	            			writer.write("No Time.");
     	            		}
     	            		
     	            		writer.write("Unknown,");
     	            		writer.write("Racer,");
     	            		writer.write(bibNums.get(k)+ ",");
     	            		writer.write("N/A,");
     		                writer.write("N/A,\r");
     	            	}    
            	} 
	            }
            }
            writer.close();
        }
        catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
		
		
	}
		
	}   
    
    
    
    


/*
 * To change textWindow template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.*;

/**
 *
 * @author Jackson Porter
 */
public class InputWindows implements ActionListener{
	JFrame textWindow, inputWindow;
	JButton submit, reset;
    //ArrayList<JLabel> intervalNum, position, velocity, acceleration;
    JTextArea display;
    JScrollPane scrollArea;
    Program program;
    private List<RaceTime> times;
    private List<String> bibNums;
    
    public InputWindows(Program p)
    {
    	program = p;
    	
    	times = new ArrayList<RaceTime>();
    	bibNums = new ArrayList<String>();
    	
    	//textWindow
        textWindow = new JFrame("Enter Bib Numbers/Names Here");
        textWindow.setBounds(250, 50, 500, 500);
        textWindow.setVisible(false);
        
        //inputWindow
        inputWindow = new JFrame("Bib Entry");
        inputWindow.setBounds(50, 50, 200, 300);
        inputWindow.setLayout(null);
        inputWindow.setVisible(false);
        
        submit = new JButton("Submit Results");
        reset = new JButton("Reset Window");
        
        submit.setBounds(20, 20, 150, 100);
        reset.setBounds(20, 140, 150, 100);
        
        submit.addActionListener(this);
        reset.addActionListener(this);
        
        inputWindow.add(submit, 0);
        inputWindow.add(reset, 0);
        
        
        
        display = new JTextArea();
        display.setBounds(0, 0, 350, 1000);
        //textWindow.add(display,0);
        //Scrolling is thanks to:
        //https://www.youtube.com/watch?v=dIVQUxJDWhY
        scrollArea = new JScrollPane(display, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        textWindow.add(scrollArea);
        

        
        //addRow("Interval:", "Y Position:", "Velocity:", "Acceleration:");
        //addRow("Interval1:", "Y Position1:", "Velocity1:", "Acceleration1:");
        
    }
    
    public void addRow(String t, String b)
    {
        String current = display.getText();
        current += t + "," + b + "\n";
        display.setText(current);
        
        textWindow.repaint();
        
    }
    
    public void reset()
    {
    	display.setText("");
    }
    
    public void scrollToTop()
    {
        //http://stackoverflow.com/questions/291115/java-swing-using-jscrollpane-and-having-it-scroll-back-to-top
        display.setCaretPosition(0);
    }
    
    public void setVisible(boolean v)
    {
    	JOptionPane.showMessageDialog(null, "Please type in the names/bib numbers of"
    			+ "each racer by clicking OK. \nEnter the names/bib numbers AFTER the comma."
    			+ "\n                            DO NOT DELETE ANY OF THE TIMES!"
    			+ "\n                            IF YOU DO, THE TIMES WILL BE LOST!!!", 
                "Bib Entry", JOptionPane.PLAIN_MESSAGE);
    	addRow("Time", "Name/Bib Number");
        textWindow.setVisible(v);
        inputWindow.setVisible(v);
        times = program.getTimes();
        
        for(int i = 0; i < times.size(); i++){
        	addRow(times.get(i).getDoubleStringTime(), "");
        }
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == submit)
		{
			this.saveBibsWithTimes();
		}
		else if(e.getSource() == reset)
		{
			this.reset();
		}
		
	}

	private void saveBibsWithTimes() {
		
		List<String> list = new ArrayList<String>();
		
		String input = display.getText();
		Scanner toScan = new Scanner(input);
		
		//System.out.println(toScan.nextLine());
		
		boolean process = true;
		
		for(int i = 0; process; i++)
		{
			try{
				String line = toScan.nextLine();
				list.add(line);
				
			}catch(java.util.NoSuchElementException e)
			{
				process = false;
			}
			
		}
		
		this.setVisible(false);
		program.saveBibsWithTimes(list);
		
	}
}

import javax.swing.*;

/**
 * Write a description of class Colon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Colon extends JComponent
{
    private Rectangle top, bottom;

    /**
     * Constructor for objects of class Colon
     */
    public Colon(int x, int y)
    {
        this.setBounds(x, y, 75, 500);
        
        top = new Rectangle(0, 75, 75, 125);
        this.add(top, 0);
        
        bottom = new Rectangle(0, 325, 75, 125);
        this.add(bottom, 0);
    }
}

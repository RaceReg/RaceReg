import java.util.*;
import java.io.*;

/**
 * Welcome to the Timer class! 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer extends TimerTask
{
    private long startTime, endTime;
    
    private java.util.Timer javaTimer;
    
    private List<RaceTime> times;
    private Program program;
    
    private TimerWin timerWin;
    private ClockWin clockWin;
    
    private int minutes;
    private int hours;
    private int seconds;
    
    
    /**
     * Constructor for objects of class Timer
     */
    public Timer(Program p)
    {
        program = p;
       
        timerWin = new TimerWin(this);
        clockWin = new ClockWin();
        
        seconds = 0;
        minutes = 0;
        hours = 0;
        
        javaTimer = new java.util.Timer();
        
        startTime = 0;
        endTime = 0;
        times = new ArrayList<RaceTime>();
    }
        
    public void setStartTime(long st)
    {
        startTime = st;
    }
    
    public long getStartTime()
    {
       return startTime; 
    }
    
    public void setEndTime(long et)
    {
        endTime = et;
    }
    
    public void startTimer(boolean v)
    {
        setStartTime(System.currentTimeMillis());
        clockWin.setVisible(v);
        javaTimer.schedule(this, 0, 1000);
    }
    
    public void lap()
    {
        long tempLong = System.currentTimeMillis();
        long currentRacerLong = tempLong - startTime;
        RaceTime tempTime = new RaceTime(currentRacerLong);
        //System.out.println("LAP: " + currentRacerLong);
        times.add(tempTime);
    }
    
    public void stopTimer()
    {
        setEndTime(System.currentTimeMillis());
    
        program.addTimes(times);
        clockWin.setVisible(false);
        
        javaTimer.cancel();
        javaTimer.purge();
    }
    
        
    public void setToVisible(boolean v)
    {
        timerWin.setToVisible(v);
    }
    
    public void run()
    {
        addSecond();
        clockWin.addSecond(seconds, minutes, hours);
    }
    
    public void addSecond()
    {
        seconds++;
        //Hours Conversion:
        hours = seconds / 3600;
        
        //Minutes Conversion:
        minutes = seconds / 60;
    }
}

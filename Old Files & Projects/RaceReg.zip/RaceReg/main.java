/**
 * This File contains the Main Method to run the Program. 
 */

/**
 * The Main class contains the main method to run the program. 
 * 
 * @author Jackson Porter
 * @version 0.1 9/4/2015
 */
public class main
{
    private static Program program;

    public static void main(String[]args)
    {
        program = new Program();
    }

}

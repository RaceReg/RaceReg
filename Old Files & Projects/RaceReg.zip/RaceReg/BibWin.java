import javax.swing.*;
import java.awt.event.*;
import java.util.*;

import java.lang.NumberFormatException;
/**
 * Write a description of class bibWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BibWin extends Window
{
    private final int numOfFields = 10;
    private JButton save, reset, next, exit, prev;

    private boolean flag;
    private Integer currentFirst;

    private BibEntry bibEntry;
    
    private List<String> bibNums;
    
    private JTextField [] field;
    private JLabel [] numbers;
    
    /**
     * Constructor for objects of class bibWin
     */
    public BibWin(BibEntry bE)
    {
        super("Bib Number Entry", 0, 0, 700, 700, false);
        bibEntry = bE;
        
        currentFirst = 0;
        flag = false;
        
        bibNums = new ArrayList<String>();
        
        next = new JButton("Next 10 Racers");
        next.setBounds(0, 550, 150, 100);
        next.addActionListener(this);
        this.add(next, 0);
        
        prev = new JButton("Previous 10 Racers");
        prev.setBounds(150, 550, 150, 100);
        prev.setVisible(false);
        prev.addActionListener(this);
        this.add(prev, 0);
        
        exit = new JButton("Save and Exit");
        exit.setBounds(400, 550, 200, 100);
        exit.addActionListener(this);
        this.add(exit, 0);        
        
        reset = new JButton("Reset ALL");
        reset.setBounds(300, 550, 100, 100);
        reset.addActionListener(this);
        this.add(reset, 0);
       

        
        
        
        
        
        field = new JTextField[10];
        int space = 50;
        for(int i = 0; i < 10; i ++)
        {
            field[i] = new JTextField();
            field[i].setBounds(100, space, 100, 50);
            space += 50;
            //field[i].setText("N/A");
            this.add(field[i], 0);
            
            field[i].setVisible(false);
        }
        
        numbers = new JLabel[10];
        space = 50;
        for(int i = 0; i < 10; i ++)
        {
            numbers[i] = new JLabel();
            numbers[i].setBounds(35, space, 100, 50);
            space += 50;
            numbers[i].setText("Racer #" + (i+1) + ":");
            this.add(numbers[i], 0);
            
            numbers[i].setVisible(false);
        }        
        
        for(int i = 0; i < 10; i ++)
        {
            field[i].setVisible(true);
            numbers[i].setVisible(true);
        }
        
        
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == next)
        {
            next();
        }
        if(e.getSource() == exit)
        {
            bibEntry.exit();
            //printList();
        }
        if(e.getSource() == reset)
        {
            if(JOptionPane.showConfirmDialog(this, "Are you sure?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE) == 0)
            {
                clearFields();
                bibNums.clear();
                
                currentFirst = 0;
                setFields(currentFirst+1);
            }
        }
        if(e.getSource() == prev)
        {
            if(currentFirst != 0)
            {
               prev(); 
            }
            else
            {
                JOptionPane.showMessageDialog(this, "You are at the beginning.", "Error", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    public void add()
    {
        //System.out.println("FLAG STATUS: " + flag);
        if(currentFirst < bibNums.size())
        {
            replace(currentFirst);
        }
        else
        {
            for(int i = 0; i < 10; i++)
            {
                bibNums.add(field[i].getText());
                currentFirst += 1;
            }            
        }
        //System.out.println("Status ADD: " + currentFirst);
        //currentFirst += 10;
    }
    
    public void next()
    {
        add();
        if(currentFirst < bibNums.size())
        {
            //System.out.println("HIT! currentFirst =" + currentFirst);
            //System.out.println(bibNums.get(10) + " is bibNums.get(currentFirst+1)");
            for(int i = 0; i < 10; i++)
            {
                //System.out.println(bibNums.get(currentFirst+i));
                field[i].setText(bibNums.get((currentFirst+i)));
            } 
        }
        else
        {
            clearFields();
        }
        setFields(currentFirst+1);    
        prev.setVisible(true);
    }
    
    public void prev()
    {
        if(flag)
        {
            //System.out.println(flag);
            flag = false;
            //System.out.println(flag);
            add();
        }
        else
        {
            add();
        }
        flag = true;   
        
        currentFirst -= 20;
        setFields(currentFirst+1);
        if(currentFirst == 0)
        {
            prev.setVisible(false);
        }
        //System.out.println("TEST" + currentFirst);
        for(int i = 0; i < 10; i++)
        {
            field[i].setText(bibNums.get(currentFirst+i));
        } 
        
    }
    
    public void replace(int baseNumber)
    {
        for(int i = 0; i < 10; i++)
        {
            //System.out.println("Before: " + bibNums.get(baseNumber));
            bibNums.set(baseNumber, field[i].getText());
            //System.out.println("After: " + bibNums.get(baseNumber));
            baseNumber++;
            currentFirst += 1;
        }
    }
    
    public String[] getFields()
    {
        String[] fieldArray = new String[10];
        
        for(int i = 0; i < 10; i++)
        {
            fieldArray[i] = field[i].getText();
        }
        return fieldArray;
    }
    
    public void clearFields()
    {
        for(int i = 0; i < 10; i++)
        {
            field[i].setText("");
        }
    }
    
    public void setFields(int baseNumber)
    {
        for(int i = 0; i < 10; i++)
        {
            numbers[i].setText("Racer #" + (baseNumber) + ":");
            baseNumber += 1;
        }
    }
    
    public List<String> getBibs()
    {
        return bibNums;
    }
    
    public void printList()
    {
        for(int i = 0; i < bibNums.size(); i++)
        {
            System.out.println(bibNums.get(i));
        }
    }
    

    //This code is old code used when bibWin and timerWin were in one class together. It was also the predessor to the current GUI bib entry interface. 
    
//     public void addTimes()
//     {
//         //JOptionPane.showMessageDialog(null, "Ready? Type in each bib number IN ORDER and hit enter. If there was no bib number, please type 'bandit' and hit enter." + times.size(), "Bib Entry", JOptionPane.INFORMATION_MESSAGE);
// 
//         this.setVisible(false);
// 
//         for(int i = 0; i < times.size(); i ++)
//         {
//            String tempString = JOptionPane.showInputDialog(null, "Enter Bib Number: ", "Bib Entry", JOptionPane.INFORMATION_MESSAGE);
//            tempString.toLowerCase();
//            if(tempString.equals("bandit"))
//            {
//                tempString = "-1";
//            }
//            int toReturn = Integer.parseInt(tempString);
//            bibNums.add(toReturn);
//         }
//         ////System.out.println(bibNums.toString());
//         this.setVisible(true);
//         bibs.setVisible(false);
//         exit.setVisible(true);
//     }
    
}

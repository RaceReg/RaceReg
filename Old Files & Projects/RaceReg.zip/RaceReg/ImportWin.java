import java.awt.event.*;
import javax.swing.*;
import java.io.*;
/**
 * Write a description of class importWin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImportWin extends Window
{
    private JLabel instructions, two, three; 
    private JButton getFile;
    private JFileChooser fileChooser;
    private Program program;
    /**
     * Constructor for objects of class importWin
     */
    public ImportWin(Program p)
    {
        super("Import", 500, 100, 700, 300, false);
        
        program = p;
        
        instructions = new JLabel("Welcome! This window will help you import your registration file."); 
        instructions.setBounds(20, 0, 500, 50);
        instructions.setVisible(true);
        this.add(instructions, 0);
        
        two = new JLabel("Please click the Get File button to get started."); 
        two.setBounds(20, 60, 500, 50);
        two.setVisible(true);
        this.add(two, 0);
        
        three = new JLabel("Don't forget! Your file must be identical to the RaceTemplate.csv file provided!"); 
        three.setBounds(20, 120, 500, 50);
        three.setVisible(true);
        this.add(three, 0);
        
        getFile = new JButton("Get File");
        getFile.setBounds(550, 150, 100, 100);
        getFile.setVisible(true);
        getFile.addActionListener(this);
        this.add(getFile, 0);
        
        fileChooser = new JFileChooser();
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == getFile)
        {
            getFile();
        }
    }
    
    public void getFile()
    {
        boolean retry = true;
        File file = new File("test");
        do{
            if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            {
                file = fileChooser.getSelectedFile();
                retry = false;
            }
            else
                JOptionPane.showMessageDialog(this, "You selected no file. You must select a file.", "Error", JOptionPane.ERROR_MESSAGE);
        }while(retry);
        program.importRacersFile(file);
    }
}

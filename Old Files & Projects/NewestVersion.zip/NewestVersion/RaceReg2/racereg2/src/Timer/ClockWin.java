package Timer;

import Window.Window;
import java.awt.event.*;
import javax.swing.*;
import Window.Window;

/**
 * Write a description of class TestFrame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ClockWin extends Window
{
    public Clock clock;
    //public JButton button;
    /**
     * Constructor for objects of class TestFrame
     */
    public ClockWin()
    {
        super("Timer", 20, 20, 1725, 1500, false);
        clock = new Clock(125, 200);
        this.add(clock, 0);
        
        //Digit test = new Digit(0,0);
        //this.add(test, 0);
        
        //Colon test = new Colon(0, 0);
        //this.add(test,0);
        
//         button = new JButton("Add Second:");
//         button.setBounds(150, 500, 100, 100);
//         button.addActionListener(this);
//         this.add(button, 0);
        
        this.repaint();
    }
    
    public void addSecond(int second, int minutes, int hours)
    {
        clock.addSecond(second, minutes, hours);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        
    }
    
    public String getCurrentTimeString()
    {
        return clock.returnTimeString();
    }
}

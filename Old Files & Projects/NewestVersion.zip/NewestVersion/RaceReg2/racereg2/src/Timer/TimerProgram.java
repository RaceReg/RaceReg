/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Timer;

import BibEntry.BibEntryProgram;
import java.util.List;
import Racer.RaceTime;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TimerTask;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Jackson Porter - RaceReg Developer
 * @version 1.0
 */
public class TimerProgram  extends TimerTask{
    TimerWindow timerWin;
    
    private long startTime, endTime;
    
    private java.util.Timer javaTimer;
    
    private List<RaceTime> times;
    //private Program program;
   
    private ClockWin clockWin;
    
    private int minutes;
    private int hours;
    private int seconds;
    
    Boolean slaveProgram;
    
    public TimerProgram()
    {
        timerWin = new TimerWindow(this);
        setToVisible(true);
        
        clockWin = new ClockWin();
        
        seconds = 0;
        minutes = 0;
        hours = 0;
        
        javaTimer = new java.util.Timer();
        
        startTime = 0;
        endTime = 0;
        times = new ArrayList<RaceTime>();
        
        slaveProgram = false;
    }
    
    public void setStartTime(long st)
    {
        startTime = st;
    }
    
    public long getStartTime()
    {
       return startTime; 
    }
    
    public void setEndTime(long et)
    {
        endTime = et;
    }
    
    public void startTimer(boolean v)
    {
        setStartTime(System.currentTimeMillis());
        //clockWin.setVisible(v);
        javaTimer.schedule(this, 0, 1000);
    }
    
    public void lap()
    {
        long tempLong = System.currentTimeMillis();
        long currentRacerLong = tempLong - startTime;
        RaceTime tempTime = new RaceTime(currentRacerLong);
        //System.out.println("LAP: " + currentRacerLong);
        times.add(tempTime);
    }
    
    public void stopTimer()
    {
        setEndTime(System.currentTimeMillis());
    
        //addTimes(times);
        //clockWin.setVisible(false);
        
        javaTimer.cancel();
        javaTimer.purge();
        JOptionPane.showMessageDialog(null, "Race Completed! Click OK to save the results.", "Race Complete", JOptionPane.INFORMATION_MESSAGE);
        addTimes();
        printTimes();
        compileResults();
        
        
//        if(!slaveProgram)
//        {
//            System.exit(0);
//        }
    }
    
    public void addTimes()
    {
        System.out.println("Saving Data.");
        JFileChooser chooser = new JFileChooser();
        File saveFile = null;
        boolean flag = true;
        
    	try
        {
            do
            {
               if(chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
               {
                   saveFile = chooser.getSelectedFile();
                   File tempFile = new File(saveFile.toString()+".csv");
                   saveFile = tempFile;
                   flag = false;
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "You must select a destination.", "Saving File", JOptionPane.ERROR_MESSAGE);
               }
            }while(flag);
            
            FileWriter fileout = new FileWriter(saveFile);
            BufferedWriter writer = new BufferedWriter(fileout);
            
            writer.write("Time\n");
    
            
            for(int i = 0; i < times.size(); i ++)
            {
                writer.write(times.get(i).getDoubleStringTime() + "\n");
            }
            writer.close();
        }
        catch(IOException ex)
        {
            System.out.println("There was an error - PROGRAM CRASH!");
            ex.printStackTrace();
        }
    }
        
    public void setToVisible(boolean v)
    {
        timerWin.setVisible(v);
    }
    
    public void run()
    {
        addSecond();
        clockWin.addSecond(seconds, minutes, hours);
        timerWin.setCurrentTime(clockWin.getCurrentTimeString());
    }
    
    public void addSecond()
    {
        seconds++;
        //Hours Conversion:
        hours = seconds / 3600;
        
        //Minutes Conversion:
        minutes = seconds / 60;
    }
    
    public void printTimes()
    {
        System.out.println("HIT PRINT");
        for(int i = 0; i < times.size(); i++)
        {
            System.out.println(times.get(i).getDoubleTime());
        }
    }

    void showClock() {
        clockWin.setVisible(true);
    }

    private void compileResults() {
        
        int result = JOptionPane.showConfirmDialog(null, "Would you like to insert names/bib numbers?", "Bib Number Entry", JOptionPane.YES_NO_OPTION);
        if(result == 0)
        {
            JOptionPane.showMessageDialog(null, "Let's begin!", "Bib Number Entry", JOptionPane.PLAIN_MESSAGE);
            BibEntryProgram bep = new BibEntryProgram(times);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Awesome! Results are saved!", "Program Complete!", JOptionPane.PLAIN_MESSAGE);
            timerWin.setVisible(false);
        }
    }
    
}

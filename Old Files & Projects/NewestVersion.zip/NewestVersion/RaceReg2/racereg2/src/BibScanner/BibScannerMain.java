/*
 * This file containts a driver program for the BibScanner side Program.
 */
package BibScanner;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is the driver program for the BibScanner program.
 * @author Jackson Porter (RaceReg Developers)
 */
public class BibScannerMain {
    /**
     * This main method will start the program. If there is an applicable program arguments, the option will be ran. 
     * @param args Program option input from command prompt/terminal. 
     */
    public static void main(String[] args)
    {
        //Initilaze variables.
        //This array contains the various terminal options and if they were marked.
        //terminalConditions[0] is to check if terminal scanner should be ran. 
        //terminalConditions[1] is to check if graphical program should be ran.
        boolean[] terminalConditions = new boolean[2];
        
        //Initialize array.
        for(int k = 0; k < terminalConditions.length; k++)
        {
            terminalConditions[k] = false;
        }
        
        try
        {
            //Scan user given arguments.
            if(args[0] != null)
            {
                //Check for various available options. 
                for(int i = 0; i < args.length; i++)
                {
                    if(args[i] == "-t")
                    {
                        terminalConditions[0] = true;
                    }
                    if(args[i] == "-g")
                    {
                        terminalConditions[1] = true;
                    }
                }

                //ERROR CODE: 0001
                if(terminalConditions[0] && terminalConditions[1])
                {
                    //Print error message. 
                    System.out.println("These options are inncorrect. You cannot run both the graphical program and the terminal program. PROGRAM QUIT (Code: 0001)");
                }
                //Terminal Program should be ran. 
                else if(terminalConditions[0])
                {
                    BibScannerProgram program = new BibScannerProgram(true);  
                }
                //Graphical Program should be ran. 
                else if(terminalConditions[1])
                {
                    BibScannerProgram program = new BibScannerProgram(false);  
                }
                //No valid options. ERROR CODE: 0002
                else
                {
                    System.out.println("You did not enter any valid options. PROGRAM QUIT. (Code: 0002)");
                }
            }
        }catch(ArrayIndexOutOfBoundsException e)
        {
             //Print to the user that the graphical interface has started.
            System.out.println("No arguments/options given. Graphical interface has started.");
            
            //Start graphical program.
            BibScannerProgram program = new BibScannerProgram(false); 
            
        }
    }
}

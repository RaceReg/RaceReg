/*
 * This file contains the program for Bib Number scanning.
 */
package BibScanner;

import Racer.Racer;
import java.util.List;

/**
 * This is the program class for the BibScanner program.
 * @author Jackson Porter (RaceReg Developers)
 * @version 1.0
 */
public class BibScannerProgram
{
    //Declare global variables. 
    BibEntryWindow window;
    final String TABS = "Last Name,First Name,Bib Number,Gender,Age,Race,";
    String[] importReqs;
    private List<Racer> racers;
    private List<String> bibNums;
    
    /**
     * Constructor for the BibScannerProgram class.
     * @param terminalLaunch is true is terminal program should start.s
     */
    public BibScannerProgram(boolean terminalLaunch)
    {
        if(terminalLaunch)
        {
            
        }
        else
        {
            window = new BibEntryWindow(this);
            window.setVisible(true);
        }
    }
}
